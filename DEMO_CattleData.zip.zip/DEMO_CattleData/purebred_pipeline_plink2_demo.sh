#!/bin/bash
# ./purebred_pipeline.sh cattle_raw 5
# ==============================
# INPUT
# ==============================
PREFIX=$1
KMAX=$2

if [ -z "$PREFIX" ] || [ -z "$KMAX" ]; then
  echo "Usage: bash purebred_pipeline_plink2.sh <plink_prefix> <max_K>"
  exit 1
fi


mkdir -p results logs plots

plink2 --vcf $PREFIX --make-pgen --allow-extra-chr --max-alleles 2 --pheno Phenotype.txt --cow --out cattle_data --sort-vars 

echo "===== STEP 1: QC (PLINK2) ====="
plink2 --pfile cattle_data \
       --geno 0.05 \
       --mind 0.05 \
       --maf 0.05 \
       --hwe 1e-6 \
       --make-bed \
       --cow \
       --out results/qc > logs/qc.log


echo "===== STEP 2: LD pruning ====="
plink2 --bfile results/qc \
       --indep-pairwise 50 5 0.2 \
       --cow\
       --out results/pruned > logs/prune.log

plink2 --bfile results/qc \
       --extract results/pruned.prune.in \
       --make-bed \
	--cow \
       --out results/pruned_data >> logs/prune.log


echo "===== STEP 3: PCA ====="
plink2 --bfile results/pruned_data \
       --pca 20\
	--cow \
       --out results/pca > logs/pca.log


echo "======== prune data correction =========="
awk '{
  if($1=="X") $1=30;
  if($1=="Y") $1=31;
  if($1=="MT") $1=32;
  print
}' results/pruned_data.bim > temp.bim

mv temp.bim results/pruned_data.bim


echo "===== STEP 4: ADMIXTURE ====="
for K in $(seq 2 $KMAX)
do
  echo "Running ADMIXTURE for K=$K"
  admixture --cv results/pruned_data.bed $K | tee logs/admixture_K${K}.log
done


echo "===== STEP 5: Extract best K ====="
grep -h CV logs/admixture_K*.log > logs/cv_errors.txt

BEST_K=$(awk '{print $3, $4}' logs/cv_errors.txt | \
         sed 's/K=//' | sed 's/)//;s/(//' | \
         sort -k2 -n | head -1 | cut -d' ' -f 1|sed 's/://')

echo "Best K = $BEST_K"

cp pruned_data.${BEST_K}.Q results/final.Q


echo "===== STEP 6: Classification ====="

awk '{
  max=0
  for(i=1;i<=NF;i++){
    if($i>max){max=$i}
  }
  if(max>=0.8){
    print "Purebred"
  } else {
    print "Crossbred"
  }
}' results/final.Q > results/classification.txt

paste results/qc.fam results/final.Q results/classification.txt > results/final_results.txt

echo "===== PIPELINE COMPLETED ====="
echo "Output: results/final_results.txt"

