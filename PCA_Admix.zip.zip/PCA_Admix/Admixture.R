#1. Visulisation of Admixture Analysis from generated data
# Admixture analysis is a statistical method used in genetics to estimate the proportion of an 
# individual's or population's ancestry derived from two or more ancestral source population

# Read data
setwd("E:/D/NIAB/PROJECT_NIAB/Fifth_Year/Objective1/Demo");dir()
Q <- as.matrix(read.table("final.Q"))
meta <- read.table("pca.eigenvec_breed.txt", header=TRUE, stringsAsFactors=FALSE)

breed <- as.factor(meta$Breed)

# 🔹 Step 1: Compute mean ancestry per breed
avg <- aggregate(Q, by=list(breed), FUN=mean)
rownames(avg) <- avg[,1]
avg <- avg[,-1]

# 🔹 Step 2: Assign each cluster to breed (max contribution)
cluster_to_breed <- apply(avg, 2, function(x) names(which.max(x)))

print("Cluster → Breed mapping:")
print(cluster_to_breed)

# 🔹 Step 3: Define PCA colors (must match your PCA plot)
breed_colors <- c(
  "Kankrej" = "red",
  "Ongole" = "green",
  "Tharparkar" = "cyan",
  "Sahiwal" = "blue",
  "Gir" = "black"
)

# 🔹 Step 4: Assign colors to clusters
cluster_colors <- breed_colors[cluster_to_breed]

# 🔹 Step 5: Order individuals by breed
ord <- order(breed)
Q <- Q[ord, ]
breed <- breed[ord]

# 🔹 Step 6: Plot
pdf("Admixture_Plot.pdf", width=22, height=8)

barplot(t(Q),
        col=cluster_colors,
        border=NA,
        space=0,
        xlab="Individuals of Breeds",
        ylab="Ancestry")

# Add breed separators
abline(v = cumsum(table(breed)), lwd=2)

# Add breed labels
midpoints <- cumsum(table(breed)) - table(breed)/2
axis(1, at=midpoints, labels=levels(breed), las=2)

# Legend (same as PCA colors)
#legend("topright",
#       legend=names(breed_colors),
#       fill=breed_colors,
#       cex=0.8)


legend(x = mean(par("usr")[1:2]),
       y = par("usr")[4] + (par("usr")[4] - par("usr")[3]) * 0.1,
       legend = names(breed_colors),
       fill = breed_colors,
       horiz = TRUE,
       bty = "n",
       xpd = TRUE,
       cex = 0.9)


dev.off()
