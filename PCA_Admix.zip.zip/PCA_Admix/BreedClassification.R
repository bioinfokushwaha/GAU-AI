## Visulalised Breed purity identification
# 
library(dplyr)
library(ggplot2)

# Load data
setwd("E:/D/NIAB/PROJECT_NIAB/Fifth_Year/Objective1/Demo");dir()
df <- read.table("final_results_breed.txt", header=FALSE, stringsAsFactors=FALSE)

colnames(df) <- c("FID","IID","V3","V4","V5","V6",
                  "Q1","Q2","Q3","Q4","Q5","Q6","Status","Breed")

# Extract Q matrix
Q <- df[, c("Q1","Q2","Q3","Q4","Q5","Q6")]

# Normalize (safety)
Q <- Q / rowSums(Q)

# Maximum ancestry per individual
df$Max_Ancestry <- apply(Q, 1, max)

# Dominant cluster
df$Major_Cluster <- apply(Q, 1, function(x) paste0("Q", which.max(x)))

# 🔥 Classification based on threshold
df$Class <- ifelse(df$Max_Ancestry >= 0.90, "Pure",
                   ifelse(df$Max_Ancestry >= 0.70, "Predominant", "Admixed"))

# View results
head(df[, c("IID","Breed","Max_Ancestry","Major_Cluster","Class")])

#write.table(df, file = "data.t", sep = "\t", row.names = FALSE)

write.table(df, "Quantitative_PurityClassification.tab", sep="\t")
png("Quantitative_PurityClassification.png", width=3500, height=1400, res=300)

ggplot(df, aes(x=Breed, fill=Class)) +
  geom_bar(position="fill") +
  ylab("Proportion") +
  ggtitle("Admixture Classification by Breed") +
  scale_fill_manual(values=c("Pure"="green",
                             "Predominant"="orange",
                             "Admixed"="red"))

theme(plot.title.position = "plot", plot.title = element_text(hjust = 1.0))

dev.off()
