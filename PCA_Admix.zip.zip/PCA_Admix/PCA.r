#1. Visulisation of PCA plot of generated data

rm(list=ls()) ## Remove the all previous variable 
##############################################################
setwd("E:/D/NIAB/PROJECT_NIAB/Fifth_Year/Objective1/Demo");dir()
# Read file correctly (TAB separated)
pca <- read.table("pca.eigenvec",header=TRUE, sep="\t", stringsAsFactors=FALSE)

# Check structure
str(pca)
summary(pca)

# Ensure numeric columns
pca[,3:22] <- lapply(pca[,3:22], as.numeric)

# Quick check
summary(pca$PC1)

# Remove NA rows (just in case)
pca <- na.omit(pca)

# TEST plot first (IMPORTANT)
plot(pca$PC1, pca$PC2)

# If above works → save PNG
png("PCA_Plot.png", width=1000, height=800)

par(mfrow=c(1,2))

plot(pca$PC1, pca$PC2,
     pch=19, col="darkgreen",
     xlab="PC1", ylab="PC2",
     main="PC1 vs PC2")

plot(pca$PC3, pca$PC4,
     pch=19, col="blue",
     xlab="PC3", ylab="PC4",
     main="PC3 vs PC4")

dev.off()

####### 2. identification of breed clusters

pca <- read.table("pca.eigenvec_breed.txt", header=TRUE, sep="\t", stringsAsFactors=FALSE)

# Define breed colors
breed_colors <- c(
  "Kankrej"="red",
  "Ongole"="green", "Tharparkar"="cyan", "Sahiwal"="blue", "Gir"="black")

# Ensure numeric PCA columns: Apply the same function to every column.
pca[,3:22] <- lapply(pca[,3:22], as.numeric) 

# Remove NA
pca <- na.omit(pca)

# IMPORTANT: map colors to each sample
cols <- breed_colors[pca$Breed]

# Load eigenvalues
eig <- scan("pca.eigenval")
var_exp <- eig / sum(eig) * 100

png("PCA_BreedCluster.png", width=3000, height=2200, res=300)

par(mfrow=c(1,2))

# ---- PC1 vs PC2 ----
plot(as.numeric(pca$PC1), as.numeric(pca$PC2),
     pch=19,
     col=cols,
     xlab=paste0("PC1 (", round(var_exp[1], 2), "%)"),
     ylab=paste0("PC2 (", round(var_exp[2], 2), "%)"),
     main="PC1 vs PC2")

# ---- PC3 vs PC4 ----
plot(as.numeric(pca$PC3), as.numeric(pca$PC4),
     pch=19,
     col=cols,
     xlab=paste0("PC3 (", round(var_exp[3], 2), "%)"),
     ylab=paste0("PC4 (", round(var_exp[4], 2), "%)"),
     main="PC3 vs PC4")

# ---- Legend (FIXED) ----
legend("topright",
       legend=names(breed_colors),
       col=breed_colors,
       pch=19)

dev.off()
